package Script;

public class NavigateAdminFolder {
	
}
