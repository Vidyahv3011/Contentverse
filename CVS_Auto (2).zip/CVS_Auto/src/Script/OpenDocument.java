package Script;

import org.openqa.selenium.WebDriver;

import Pom.OpenDoc;
import Pom.ViewerToolbar;

public class OpenDocument {
	
	private WebDriver driver;

	OpenDocument(WebDriver driver) {
		this.driver = driver;
	}

	public void testOpenDocument() throws Exception{
		
		OpenDoc OC=new OpenDoc(driver);
		OC.SetExpandNode();
		OC.DocumentOpen();
		Thread.sleep(3000);
		ViewerToolbar view = new ViewerToolbar(driver);
		view.SetCloseViewer();
	}

}
