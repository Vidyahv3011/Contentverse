package Script;

public class SendToSecurelink {

}
