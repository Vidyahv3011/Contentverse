package Script;

import org.openqa.selenium.WebDriver;




public class RecentFolder {
	private WebDriver driver;

	RecentFolder(WebDriver driver) {
		this.driver = driver;
	}

	public void testRecentFolder() throws Exception{
		
		RecentFolderDocument rec=new RecentFolderDocument(driver);
	    rec.SetRecentFolder();
	    //rec.SetRecentDocument();
		
	
	}


}
