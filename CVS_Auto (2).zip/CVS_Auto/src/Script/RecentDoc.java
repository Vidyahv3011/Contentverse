package Script;

import org.openqa.selenium.WebDriver;

import Pom.RecentFolderDocument;




public class RecentDoc {
	private WebDriver driver;

	RecentDoc(WebDriver driver) {
		this.driver = driver;
	}

	public void testRecent() throws Exception{
		
		RecentFolderDocument rec=new RecentFolderDocument(driver);
	    //rec.SetRecentFolder();
	    rec.SetRecentDocument();
		
	
	}


}
