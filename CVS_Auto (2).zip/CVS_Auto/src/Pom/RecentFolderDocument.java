package Pom;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RecentFolderDocument {
	@FindBy(xpath = ("//a[@id='recentMenuBtn']"))
	private WebElement RecentTab;
	
	@FindBy(xpath = ("//table[@id='recentFolders']/tbody/tr[1]/td[1]"))
	private WebElement RecentFolder;
	
	@FindBy(xpath = (".//table[@id='recentDocuments']/tbody/tr[1]/td[1]"))
	private WebElement RecentDocument;
	
	public WebDriver driver;
	Actions action;

	public RecentFolderDocument(WebDriver driver) {
		PageFactory.initElements(driver, this);
		action = new Actions(driver);

		this.driver = driver;
	}
	public void SetRecentFolder() throws InterruptedException {
	action.moveToElement(RecentTab).perform();
	
WebDriverWait wait = new WebDriverWait(driver, 10);
	WebElement element = wait.until(ExpectedConditions.elementToBeClickable(RecentFolder)); 
	((JavascriptExecutor)driver).executeScript("arguments[0].click();", element);
	action.moveToElement(RecentFolder).perform();
	}
	
	public void SetRecentDocument() {
		action.moveToElement(RecentTab).perform();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(RecentDocument)); 
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", element);
		
		action.moveToElement(RecentDocument).perform();
		}
	
}
